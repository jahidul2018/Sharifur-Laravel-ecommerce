@extends('master')
@section('content')
<div class="congrats">
<div class="container">
    <div class="row">
        <div class="col-md-8 text-center col-md-offset-2">

                <h3>Thanks For Purchase Your Shopping, Enjoy !!!</h3>
                <img src="{{url('/')}}/images/congrats.jpg" alt="Congratulation Image">
            </div>
        </div>
    </div>
</div>
@endsection